package com.firstappl.oana.firstapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {


    EditText mEdit;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void onClick(View v){

        mEdit   = (EditText)findViewById(R.id.editText);
        String text  =  mEdit.getText().toString();
        if(text==null || text.length()<5 || text.contains(" ")){
            Toast.makeText(getApplicationContext(), "Please insert a text that has more than 5 characters!", Toast.LENGTH_LONG).show();
        }else{
               if(isPalindrome(text)==true){
                   Toast.makeText(getApplicationContext(), "Your text is a palindrome", Toast.LENGTH_LONG).show();
               }else{
                   Toast.makeText(getApplicationContext(), "Your text is not a palindrome", Toast.LENGTH_LONG).show();
               }

        }


    }

    public static boolean isPalindrome(String str) {
        return str.equals(new StringBuilder(str).reverse().toString());
    }

}
